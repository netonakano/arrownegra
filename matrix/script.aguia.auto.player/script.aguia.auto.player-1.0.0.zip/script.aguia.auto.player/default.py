# -*- coding: utf-8 -*-
import six
import os
from kodi_six import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs
addon = xbmcaddon.Addon()
addonname = addon.getAddonInfo('name')
icon = addon.getAddonInfo('icon')
translate = xbmcvfs.translatePath if six.PY3 else xbmc.translatePath
userdata_kodi = translate('special://home/userdata')
player = os.path.join(userdata_kodi, "playercorefactory.xml")
home = translate(addon.getAddonInfo('path')) if six.PY3 else translate(addon.getAddonInfo('path')).decode('utf-8')
folder_players = os.path.join(home, "players")


def platform():
    from kodi_six import xbmc

    if xbmc.getCondVisibility('system.platform.android'):
        return 'android'
    elif xbmc.getCondVisibility('system.platform.linux') or xbmc.getCondVisibility('system.platform.linux.Raspberrypi'):
        return 'linux'
    elif xbmc.getCondVisibility('system.platform.windows'):
        return 'windows'
    elif xbmc.getCondVisibility('system.platform.osx'):
        return 'osx'
    elif xbmc.getCondVisibility('system.platform.atv2'):
        return 'atv2'
    elif xbmc.getCondVisibility('system.platform.ios') or xbmc.getCondVisibility('system.platform.darwin'):
        return 'ios'

def msg(name):
    new_msg = '%s player applied!'%str(name)
    ok = xbmcgui.Dialog().ok(addonname, new_msg)

def copy2folder(folder):
    try:
        os.remove(player)
    except:
        pass    
    source = os.path.join(folder_players, folder, "playercorefactory.xml")
    destination = player
    xbmcvfs.copy(source,destination)
    msg(folder)

def alert(s):
    new_msg = 'your system is not %s!'%str(s)
    ok = xbmcgui.Dialog().ok(addonname, new_msg)



def players(items):
    op = xbmcgui.Dialog().select('SELECT A PLAYER BELOW:', items)
    return op

def build_itens():
    items = ['DEFAULT PLAYER', 'ArchosVideo', 'BSPlayerFree', 'DaroonPlayer', 'DicePlayerFree', 'DicePlayerPaid', 'JustPlayer', 'MoboplayerFree', 'mVideoplayerFree', 'MXPayerFree', 'MXPlayerPro', 'PotPlayer(windows)', 'RockPlayer', 'RockPlayerLite', 'SopCast', 'TPlayer', 'VLC(windows 64)', 'VLC(windows x86)', 'VLCPayer', 'Vplater', 'WondersharePlayer', 'VLC(Linux)', 'Celluloid(Linux)']
    op = players(items)
    if op == 0:
        try:
            os.remove(player)
        except:
            pass
        msg('default')
    elif op == 1:
        if platform() == 'android':
            copy2folder('ArchosVideo')
        else:
            alert('android')
    elif op == 2:
        if platform() == 'android':
            copy2folder('BSPlayerFree')
        else:
            alert('android')
    elif op == 3:
        if platform() == 'android':
            copy2folder('DaroonPlayer')
        else:
            alert('android')
    elif op == 4:
        if platform() == 'android':
            copy2folder('DicePlayerFree')
        else:
            alert('android')
    elif op == 5:
        if platform() == 'android':
            copy2folder('DicePlayerPaid')
        else:
            alert('android')
    elif op == 6:
        if platform() == 'android':
            copy2folder('JustPlayer')
        else:
            alert('android')
    elif op == 7:
        if platform() == 'android':
            copy2folder('MoboplayerFree')
        else:
            alert('android')
    elif op == 8:
        if platform() == 'android':
            copy2folder('mVideoplayerFree')
        else:
            alert('android')  
    elif op == 9:
        if platform() == 'android':
            copy2folder('MXPayerFree')
        else:
            alert('android')
    elif op == 10:
        if platform() == 'android':
            copy2folder('MXPlayerPro')
        else:
            alert('android')
    elif op == 11:
        if platform() == 'windows':
            copy2folder('PotPlayer(windows)')
        else:
            alert('windows')
    elif op == 12:
        if platform() == 'android':
            copy2folder('RockPlayer')
        else:
            alert('android')
    elif op == 13:
        if platform() == 'android':
            copy2folder('RockPlayerLite')
        else:
            alert('android')
    elif op == 14:
        if platform() == 'android':
            copy2folder('SopCast')
        else:
            alert('android')
    elif op == 15:
        if platform() == 'android':
            copy2folder('TPlayer')
        else:
            alert('android')
    elif op == 16:
        if platform() == 'windows':
            copy2folder('VLC(windows 64)')
        else:
            alert('windows')
    elif op == 17:
        if platform() == 'windows':
            copy2folder('VLC(windows x86)')
        else:
            alert('windows')
    elif op == 18:
        if platform() == 'android':
            copy2folder('VLCPayer')
        else:
            alert('android')
    elif op == 19:
        if platform() == 'android':
            copy2folder('Vplater')
        else:
            alert('android')
    elif op == 20:
        if platform() == 'android':
            copy2folder('WondersharePlayer')
        else:
            alert('android')
    elif op == 21:
        if platform() == 'linux':
            copy2folder('VLC(Linux)')
        else:
            alert('linux')
    elif op == 21:
        if platform() == 'linux':
            copy2folder('Celluloid(Linux)')
        else:
            alert('linux')                                                                                                                                                                                                         


if __name__ == '__main__': build_itens()