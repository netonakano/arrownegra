# -*- coding: utf-8 -*-
from libs import plugin
plugin.run()